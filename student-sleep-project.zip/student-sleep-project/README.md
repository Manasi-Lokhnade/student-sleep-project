# Student Sleep & GPA Prediction

This project predicts **student GPA (0–4 scale)** based on lifestyle, sleep, and academic metrics.

## Features
- Regression model (RandomForestRegressor)
- Clean training pipeline (scikit-learn + ColumnTransformer)
- Streamlit app for live predictions
- CI/CD using GitHub Actions
- Unit tests for predictor

---

## Project Structure
